from torch_tensorrt.ts._compiler import *
from torch_tensorrt.ts._compile_spec import TensorRTCompileSpec
